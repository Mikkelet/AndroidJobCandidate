package app.storytel.candidate.com;

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import app.storytel.candidate.com.features.details.DetailsActivity
import app.storytel.candidate.com.models.PostAndImages
import com.bumptech.glide.RequestManager
import java.util.*

class PostAdapter(private val requestManager: RequestManager, private val callback:Callback) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    interface Callback{
        fun onBodyClick()
    }

    private lateinit var mData: PostAndImages;

    override fun onBindViewHolder(holder:PostViewHolder ,  position:Int) {
        holder.title.text = mData.mPosts?.get(position)?.title ?: "";
        holder.body.text = mData.mPosts?.get(position)?.body ?: "";
        val photoSize = mData.mPhotos?.size ?: 1
        val index = Random().nextInt(photoSize);
        val imageUrl = mData.mPhotos?.get(index)?.thumbnailUrl ?: "";
        requestManager.load(imageUrl).into(holder.image);
        holder.body.setOnClickListener {
            callback.onBodyClick()
        };
    }

    fun setData( data:PostAndImages) {
        mData = data;
        notifyDataSetChanged();
    }

    override fun getItemCount(): Int {
        return mData.mPosts?.size ?: 0
    }

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var title: TextView = itemView.findViewById(R.id.title);
        var body: TextView = itemView.findViewById(R.id.body);
        var image: ImageView = itemView.findViewById(R.id.image);
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        return PostViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.post_item, parent, false));
    }
}

