package app.storytel.candidate.com.features.details

import android.os.Bundle
import app.storytel.candidate.com.databinding.ActivityDetailsBinding
import app.storytel.candidate.com.utils.base.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DetailsActivity : BaseActivity<DetailsContract.View,ActivityDetailsBinding>(), DetailsContract.View {
    //private static final String COMMENTS_URL = "https://jsonplaceholder.typicode.com/posts/{id}/comments"

    override lateinit var binder:ActivityDetailsBinding

    @Inject
    override lateinit var presenter: DetailsContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupView()
        binder = ActivityDetailsBinding.inflate(layoutInflater)

        //TODO display the selected post from ScrollingActivity. Use mImageView and mTextView for image and body text. Change the title to use the post title
        //TODO load top 3 comments from COMMENTS_URL into the 3 card views

    }

    private fun setupView(){
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binder.apply {
            setSupportActionBar(toolbar)
        }
    }
}
