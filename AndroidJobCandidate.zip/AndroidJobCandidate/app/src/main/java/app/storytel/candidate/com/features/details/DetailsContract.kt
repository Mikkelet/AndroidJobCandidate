package app.storytel.candidate.com.features.details

import androidx.lifecycle.LifecycleOwner
import app.storytel.candidate.com.utils.base.BasePresenter
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

object DetailsContract {
    interface View: LifecycleOwner
    interface Presenter:BasePresenter<View>

    @Module
    @InstallIn(SingletonComponent::class)
    abstract class DetailsModule{
        @Binds
        abstract fun provideDetailsPresenter(presenter:DetailsPresenter):Presenter
    }
}