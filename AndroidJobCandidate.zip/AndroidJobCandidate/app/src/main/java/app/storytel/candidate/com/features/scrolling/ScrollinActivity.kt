package app.storytel.candidate.com.features.scrolling

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import app.storytel.candidate.com.PostAdapter
import app.storytel.candidate.com.R
import app.storytel.candidate.com.databinding.ActivityScrollingBinding
import app.storytel.candidate.com.models.PostAndImages
import app.storytel.candidate.com.utils.base.BaseActivity
import com.bumptech.glide.Glide
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ScrollinActivity : BaseActivity<ScrollingContract.View, ActivityScrollingBinding>(), ScrollingContract.View, PostAdapter.Callback {

    private lateinit var mPostAdapter: PostAdapter

    override lateinit var binder:ActivityScrollingBinding

    @Inject
    override lateinit var presenter: ScrollingContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupView()
        presenter.onCreate()
    }

    private fun setupView(){
        setSupportActionBar(binder.toolbar)
        binder = ActivityScrollingBinding.inflate(layoutInflater)
        mPostAdapter = PostAdapter(Glide.with(this), this)
        binder.content
        binder..apply {
            layoutManager = LinearLayoutManager(this@ScrollinActivity, LinearLayoutManager.VERTICAL, false)
            adapter = mPostAdapter
        }
    }

    override fun onBodyClick() {

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == R.id.action_settings) true
        else super.onOptionsItemSelected(item)
    }

    override fun onDataLoaded(data: PostAndImages) {
        mPostAdapter.setData(data)
    }


}