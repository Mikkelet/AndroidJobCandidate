package app.storytel.candidate.com.features.details

import app.storytel.candidate.com.utils.base.BasePresenterImpl
import javax.inject.Inject

class DetailsPresenter @Inject constructor() : BasePresenterImpl<DetailsContract.View>(),DetailsContract.Presenter {

    private fun get(){

    }
}