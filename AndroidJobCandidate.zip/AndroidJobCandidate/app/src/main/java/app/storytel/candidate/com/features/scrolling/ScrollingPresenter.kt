package app.storytel.candidate.com.features.scrolling

import androidx.lifecycle.lifecycleScope
import app.storytel.candidate.com.features.details.DetailsContract
import app.storytel.candidate.com.models.Photo
import app.storytel.candidate.com.models.PostAndImages
import app.storytel.candidate.com.utils.base.BasePresenter
import app.storytel.candidate.com.utils.base.BasePresenterImpl
import app.storytel.candidate.com.utils.networking.ApiService
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class ScrollingPresenter @Inject constructor(
        private val apiService: ApiService
) : BasePresenterImpl<ScrollingContract.View>(), ScrollingContract.Presenter {


    override fun onCreate() {
        getView()?.lifecycleScope?.launch {
            val photos = apiService.getPhotos()
            val posts = apiService.getPosts()
            getView()?.onDataLoaded(PostAndImages(posts,photos))
        }
    }

    override fun onDestroy() {

    }
}