package app.storytel.candidate.com.models;

data class PostAndImages(
        val mPosts:List<Post>?,
        val mPhotos:List<Photo>?
)
